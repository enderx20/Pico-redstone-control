package com.mojang.renderpearl.api.pipeline;

import com.mojang.renderpearl.util.UncheckedAutoCloseable;
import org.jspecify.annotations.Nullable;

public interface CompiledRenderPipeline extends UncheckedAutoCloseable {
	boolean isClosed();

	@FunctionalInterface
	interface Pending {
		CompiledRenderPipeline.Pending NULL = () -> null;

		@Nullable CompiledRenderPipeline finishCompile();
	}
}
