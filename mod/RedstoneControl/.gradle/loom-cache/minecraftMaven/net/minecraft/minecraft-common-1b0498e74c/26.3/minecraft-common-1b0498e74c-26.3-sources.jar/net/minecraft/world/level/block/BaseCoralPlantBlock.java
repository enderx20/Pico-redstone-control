package net.minecraft.world.level.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Access widened by fabric-transitive-access-wideners-v1 to accessible
 */
public class BaseCoralPlantBlock extends BaseCoralPlantTypeBlock {
	private static final VoxelShape SHAPE = Block.column(12.0, 0.0, 15.0);

	/**
	 * Access widened by fabric-transitive-access-wideners-v1 to accessible
	 */
	public BaseCoralPlantBlock(final BlockBehaviour.Properties properties) {
		super(properties);
	}

	@Override
	protected VoxelShape getShape(final BlockState state, final BlockGetter level, final BlockPos pos, final CollisionContext context) {
		return SHAPE;
	}
}
